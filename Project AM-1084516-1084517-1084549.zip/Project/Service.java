public class Service extends Entity
{
    private String String;
    public String getDetails() {
        return "Service";
    }
}


