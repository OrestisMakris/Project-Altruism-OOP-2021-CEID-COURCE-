public class Admin extends User {

    private static boolean isAdmin = true ;

    public boolean getAdmin() // return the information that the user is admin
    {
        return isAdmin;
    }

}

